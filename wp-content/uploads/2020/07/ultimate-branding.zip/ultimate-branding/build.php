<?php
define( 'BRANDA_BUILD_TYPE', 'full' );