<style type="text/css" id="<?php echo esc_attr( $id ); ?>">
.branda-widget img {
    max-width: 100%;
    height: auto;
}
</style>