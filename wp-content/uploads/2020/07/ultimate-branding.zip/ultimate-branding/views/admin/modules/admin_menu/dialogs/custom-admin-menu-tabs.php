<script type="text/html" id="tmpl-menu-tabs">
	<div class="sui-tabs sui-tabs-overflow sui-tabs-flushed" style="display: none;">
		<div class="sui-tabs-navigation"
		     tabindex="-1"
		     aria-hidden="true">

			<button type="button" class="sui-button-icon sui-tabs-navigation--left">
				<i class="sui-icon-chevron-left"></i>
			</button>

			<button type="button" class="sui-button-icon sui-tabs-navigation--right">
				<i class="sui-icon-chevron-right"></i>
			</button>
		</div>

		<div class="sui-tabs-menu"
		     role="tablist">
		</div>

		<div class="sui-tabs-content">
		</div>
	</div>
</script>