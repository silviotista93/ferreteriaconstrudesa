<script type="text/html" id="tmpl-notice-top">
	<div class="sui-notice-top sui-notice-success">
		<div class="sui-notice-content">
			<p>{{ data.message }}</p>
		</div>
	</div>
</script>