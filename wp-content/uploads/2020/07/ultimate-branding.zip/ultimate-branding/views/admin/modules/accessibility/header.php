<?php
/**
 * Admin settings page header.
 *
 * @since 3.0.0
 */
?>
<div class="sui-box-header">
	<h3 class="sui-box-title"><?php esc_html_e( 'Accessibility', 'ub' ); ?></h3>
</div>