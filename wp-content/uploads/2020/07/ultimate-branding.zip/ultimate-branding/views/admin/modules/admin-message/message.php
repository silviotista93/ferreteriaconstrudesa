<div id="branda-message" class="updated">
    <div class="branda-content"><?php echo $message; ?></div>
</div>