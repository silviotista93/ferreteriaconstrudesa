<style type="text/css" id="<?php echo esc_attr( $id ); ?>">
#branda-message .branda-content:after {
    content:  "";
    display: block;
    clear: both;
}
#branda-message .branda-content {
    padding: 12px 0;
}
#branda-message .branda-content p:first-child {
    margin-top: 0;
}
#branda-message .branda-content p:last-child {
    margin-bottom: 0;
}
</style>