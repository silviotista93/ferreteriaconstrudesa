<?php
/**
 * Admin settings page header.
 *
 * @since 3.1.0
 */
?>
<div class="sui-box-header">
	<h3 class="sui-box-title"><?php esc_html_e( 'Permissions', 'ub' ); ?></h3>
</div>