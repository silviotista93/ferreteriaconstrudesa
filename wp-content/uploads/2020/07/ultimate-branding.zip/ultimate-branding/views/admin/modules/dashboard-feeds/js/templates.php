<script type="text/html" id="tmpl-<?php echo esc_attr( $id ); ?>-row">
    <li>
        <label>
            <span class="branda-title">{{data.title}}</span>
            <small class="branda-href">{{data.href}}</small>
        </label>
    </li>
</script>
