<script type="text/html" id="tmpl-menu-tab-content">
	<div role="tabpanel"
	     tabindex="0"
	     id="branda-custom-admin-menu-tab-content-{{ data.key }}"
	     class="sui-tab-content <# if(data.is_active) { #>active<# } #>"
	     aria-labelledby="branda-custom-admin-menu-tab-{{ data.key }}">
	</div>
</script>